package com.pooja.blog.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pooja.blog.payloads.JwtAuthResponse;
import com.pooja.blog.payloads.LoginDTO;
import com.pooja.blog.payloads.RegisterDTO;
import com.pooja.blog.service.AuthService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	private AuthService authService;

	public AuthController(AuthService authService) {
		this.authService = authService;
	}

	// build login rest api
	// @PostMapping("login")// sometimes user wants signin instead of login to
	// support multiple urls use below
	@PostMapping(value = { "/login", "/signin" })
	/*
	 * public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO) { //
	 * login method returns string String response = authService.login(loginDTO);
	 * return ResponseEntity.ok(response); }
	 */
	// changing above login method with respect to jwt
	public ResponseEntity<JwtAuthResponse> login(@RequestBody LoginDTO loginDTO) {

		String token = authService.login(loginDTO);
		JwtAuthResponse jwtAuthResponse = new JwtAuthResponse();
		jwtAuthResponse.setAccessToken(token);
		return ResponseEntity.ok(jwtAuthResponse);
	}

	// build register rest api
	@PostMapping(value = { "/register", "/signup" })
	public ResponseEntity<String> register(@RequestBody RegisterDTO registerDTO) {
		// login method returns string
		String response = authService.register(registerDTO);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
}
