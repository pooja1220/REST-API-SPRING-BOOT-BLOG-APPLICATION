package com.pooja.blog.service.impl;

import java.util.HashSet;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.pooja.blog.exception.BlogApiException;
import com.pooja.blog.model.Role;
import com.pooja.blog.model.User;
import com.pooja.blog.payloads.LoginDTO;
import com.pooja.blog.payloads.RegisterDTO;
import com.pooja.blog.repository.RoleRepository;
import com.pooja.blog.repository.UserRepository;
import com.pooja.blog.security.JwtTokenProvider;
import com.pooja.blog.service.AuthService;

@Service
public class AuthServiceImpl implements AuthService {

	private AuthenticationManager authenticationManager;
	private UserRepository userRepository;
	private RoleRepository roleRepository;
	private PasswordEncoder passwordEncoder;
	private JwtTokenProvider jwtTokenProvider;

	public AuthServiceImpl(AuthenticationManager authenticationManager, UserRepository userRepository,
			RoleRepository roleRepository, PasswordEncoder passwordEncoder, JwtTokenProvider jwtTokenProvider) {
		this.authenticationManager = authenticationManager;
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
		this.passwordEncoder = passwordEncoder;
		this.jwtTokenProvider = jwtTokenProvider;
	}

	@Override
	public String login(LoginDTO loginDTO) {
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginDTO.getUsernameOrEmail(), loginDTO.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		// generate jwt token
		String token = jwtTokenProvider.generateToken(authentication);
		return token;
		// return "User logged in successfully";
	}

	@Override
	public String register(RegisterDTO registerDTO) {
		// check if username already exists in db
		if (userRepository.existsByUsername(registerDTO.getUsername())) {
			throw new BlogApiException(HttpStatus.BAD_REQUEST, "Username already exists!");
		}

		// check if email already exists in db
		if (userRepository.existsByEmail(registerDTO.getEmail())) {
			throw new BlogApiException(HttpStatus.BAD_REQUEST, "Email already exists!");
		}

		User user = new User();
		user.setName(registerDTO.getName());
		user.setUsername(registerDTO.getUsername());
		user.setEmail(registerDTO.getEmail());
		user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));

		Set<Role> roles = new HashSet<>();
		Role userRole = roleRepository.findByName("ROLE_USER").get();
		roles.add(userRole);
		user.setRoles(roles);

		userRepository.save(user);
		return "User Registered Successfully";
	}

}
