package com.pooja.blog.service;

import java.util.List;

import com.pooja.blog.payloads.CommentDTO;

public interface CommentService {
	CommentDTO createComment(long postId, CommentDTO commentDTO);

//for get all comments by post id
	List<CommentDTO> getCommentsByPostId(long postId);

	// get comment by comment id and post id
	CommentDTO getCommentById(Long postId, Long commentId);

	// update by id
	CommentDTO updateComment(Long postId, Long commentId, CommentDTO commentRequest);

	// delete by id
	void deleteComment(Long postId, Long commentId);
}
