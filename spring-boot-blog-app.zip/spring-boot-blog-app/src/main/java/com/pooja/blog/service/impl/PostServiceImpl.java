package com.pooja.blog.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.pooja.blog.exception.ResourceNotFoundException;
import com.pooja.blog.model.Post;
import com.pooja.blog.payloads.PostDTO;
import com.pooja.blog.payloads.PostResponse;
import com.pooja.blog.repository.PostRepository;
import com.pooja.blog.service.PostService;

@Service
public class PostServiceImpl implements PostService {

	// whenever we configure our class as spring bean and the clas shas only one
	// constructor then we can omit @Autowired annotation

	private PostRepository postRepository;// injecting PostRepository

	private ModelMapper mapper;// injecting model mapper bean

	// constructor based dependency injection for PostRepository
//	public PostServiceImpl(PostRepository postRepository) {
	// this.postRepository = postRepository;
	// }
	// adding constructor based dependency injection for ModelMapper
	public PostServiceImpl(PostRepository postRepository, ModelMapper mapper) {
		this.postRepository = postRepository;
		this.mapper = mapper;
	}

	@Override
	public PostDTO createPost(PostDTO postDTO) {
		// convert DTO into entity
		/*
		 * Post post = new Post(); post.setTitle(postDTO.getTitle());
		 * post.setContent(postDTO.getContent());
		 * post.setDescription(postDTO.getDescription());
		 */
		// replacing the above code with mapToEntity method
		Post post = mapToEntity(postDTO);

		Post newPost = postRepository.save(post);// save method returns entity
		// converting this PostEntity into PostDTO
		/*
		 * PostDTO postResponse = new PostDTO(); postResponse.setId(newPost.getId());
		 * postResponse.setTitle(newPost.getTitle());
		 * postResponse.setContent(newPost.getContent());
		 * postResponse.setDescription(newPost.getDescription());
		 */
		// replacing the above with the mapToDTO method
		PostDTO postResponse = mapToDTO(newPost);

		return postResponse;
	}

	@Override
	// public List<PostDTO> getAllPosts() {
	// adding pagination changes to above line
//	public List<PostDTO> getAllPosts(int pageNo, int pageSize) {
	// change above return type to PostResponse
	// public PostResponse getAllPosts(int pageNo, int pageSize, String sortBy) {
	// add sortDir parameter
	public PostResponse getAllPosts(int pageNo, int pageSize, String sortBy, String sortDir) {
		// sorting condition
		Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
				: Sort.by(sortBy).descending();
		// create pageable instance
		// Pageable pageable = PageRequest.of(pageNo, pageSize);
		// change above pageable with pagination and sorting
		// Pageable pageable = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
		// adding above condition sort object
		Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		// pass the pageable instance in the below lineF
		// List<Post> posts = postRepository.findAll();
		Page<Post> page = postRepository.findAll(pageable);
		// this page class has an getContent method , we need to get content from this
		// page
		// get content for page object
		List<Post> listOfPosts = page.getContent();
		// now we need to comvert list of posts into list of postDTO's
		// return posts.stream().map(post ->
		// mapToDTO(post)).collect(Collectors.toList());
		// pass listOfPosts to streams in above line make changes
		// return listOfPosts.stream().map(post ->
		// mapToDTO(post)).collect(Collectors.toList());

		// change above statement according to PostResponse and creating postResponse
		// object
		List<PostDTO> content = listOfPosts.stream().map(post -> mapToDTO(post)).collect(Collectors.toList());
		// creating PostResponse object
		PostResponse postResponse = new PostResponse();
		postResponse.setContent(content);
		postResponse.setPageNo(page.getNumber());// you can get pageNo from page object
		postResponse.setPageSize(page.getSize());
		postResponse.setTotalElements(page.getTotalElements());
		postResponse.setTotalPage(page.getTotalPages());
		postResponse.setLast(page.isLast());
		return postResponse;

	}

	// convert PostEntity into PostDTO
	/*
	 * private PostDTO mapToDTO(Post post) { PostDTO postDTO = new PostDTO();
	 * postDTO.setId(post.getId()); postDTO.setTitle(post.getTitle());
	 * postDTO.setContent(post.getContent());
	 * postDTO.setDescription(post.getDescription()); return postDTO; }
	 */

	// change above method using ModelMapper
	private PostDTO mapToDTO(Post post) {
		PostDTO postDTO = mapper.map(post, PostDTO.class);
		return postDTO;
	}

	// convert PostDTO into PostEntity
	/*
	 * private Post mapToEntity(PostDTO postDTO) { Post post = new Post();
	 * post.setTitle(postDTO.getTitle()); post.setContent(postDTO.getContent());
	 * post.setDescription(postDTO.getDescription()); return post; }
	 */
	// change above method using mapper
	private Post mapToEntity(PostDTO postDTO) {
		Post post = mapper.map(postDTO, Post.class);
		return post;

	}

	@Override
	public PostDTO getPostById(Long id) {
		Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
		// convert post entity into dto
		return mapToDTO(post);
	}

	@Override
	public PostDTO updatePost(PostDTO postDTO, long id) {
		Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
		post.setTitle(postDTO.getTitle());
		post.setContent(postDTO.getContent());
		post.setDescription(postDTO.getDescription());
		Post updatedPost = postRepository.save(post);
		return mapToDTO(updatedPost);
	}

	@Override
	public void deletePostById(long id) {
		Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
		postRepository.delete(post);
	}

}
