package com.pooja.blog.payloads;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class PostDTO {
	private Long id;
	// post title should not be empty or null
	// post title should have atleast 2 characters
	@NotEmpty
	@Size(min = 2, message = "Post title should have atleast 2 characters")
	private String title;
	// post description should not be empty or null
	// post description should have atleast 10 characters
	@NotEmpty
	@Size(min = 10, message = "Post description should have atleast 10 characters")
	private String description;
	// post content should not be empty or null
	@NotEmpty
	private String content;
	private Set<CommentDTO> comments;
}
