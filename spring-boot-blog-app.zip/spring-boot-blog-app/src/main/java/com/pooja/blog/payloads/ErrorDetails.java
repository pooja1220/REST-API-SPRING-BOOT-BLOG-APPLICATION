package com.pooja.blog.payloads;

import java.util.Date;

public class ErrorDetails {
	private Date timstamp;
	private String message;
	private String details;

	public ErrorDetails(Date timstamp, String message, String details) {
		this.timstamp = timstamp;
		this.message = message;
		this.details = details;
	}

	public Date getTimstamp() {
		return timstamp;
	}

	public String getMessage() {
		return message;
	}

	public String getDetails() {
		return details;
	}

}
