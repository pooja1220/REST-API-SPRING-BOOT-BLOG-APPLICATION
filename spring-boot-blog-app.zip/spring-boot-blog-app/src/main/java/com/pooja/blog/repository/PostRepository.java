package com.pooja.blog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pooja.blog.model.Post;

public interface PostRepository extends JpaRepository<Post, Long> {

}
