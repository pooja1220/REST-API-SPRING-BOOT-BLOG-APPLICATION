package com.pooja.blog.service;

import com.pooja.blog.payloads.LoginDTO;
import com.pooja.blog.payloads.RegisterDTO;

public interface AuthService {
	String login(LoginDTO loginDTO);

	String register(RegisterDTO registerDTO);

}
