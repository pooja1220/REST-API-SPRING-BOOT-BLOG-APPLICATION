package com.pooja.blog.service;

import java.util.List;

import com.pooja.blog.payloads.PostDTO;
import com.pooja.blog.payloads.PostResponse;

public interface PostService {
	PostDTO createPost(PostDTO postDTO);

	// List<PostDTO> getAllPosts();
	// making pagination changes to above method definition and adding pageNo and
	// pageSize paramters
	// List<PostDTO> getAllPosts(int pageNo, int pageSize);
	// change return type to post response
	//PostResponse getAllPosts(int pageNo, int pageSize,String sortBy);
	//add sortDir parameter
	PostResponse getAllPosts(int pageNo, int pageSize,String sortBy,String sortDir);

	PostDTO getPostById(Long id);

	PostDTO updatePost(PostDTO postDTO, long id);

	void deletePostById(long id);
}
