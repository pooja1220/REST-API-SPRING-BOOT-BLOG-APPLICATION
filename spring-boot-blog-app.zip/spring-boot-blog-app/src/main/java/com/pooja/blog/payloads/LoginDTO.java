package com.pooja.blog.payloads;

import java.util.Set;

import com.pooja.blog.model.Role;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LoginDTO {
	private String usernameOrEmail;// login using username or email
	private String password;

}
