package com.pooja.blog.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.pooja.blog.exception.BlogApiException;
import com.pooja.blog.exception.ResourceNotFoundException;
import com.pooja.blog.model.Comment;
import com.pooja.blog.model.Post;
import com.pooja.blog.payloads.CommentDTO;
import com.pooja.blog.repository.CommentRepository;
import com.pooja.blog.repository.PostRepository;
import com.pooja.blog.service.CommentService;

@Service
public class CommentServiceImpl implements CommentService {

	private CommentRepository commentRepository;
	private PostRepository postRepository;
	private ModelMapper mapper;

	public CommentServiceImpl(CommentRepository commentRepository, PostRepository postRepository, ModelMapper mapper) {
		this.commentRepository = commentRepository;
		this.postRepository = postRepository;
		this.mapper = mapper;
	}

	@Override
	public CommentDTO createComment(long postId, CommentDTO commentDTO) {
		Comment comment = mapToEntity(commentDTO);
		// retrieve post entity by id
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));
		// set post to comment entity
		comment.setPost(post);
		// comment entity to db
		Comment newComment = commentRepository.save(comment);
		return mapToDTO(newComment);
	}

	private CommentDTO mapToDTO(Comment comment) {
		/*
		 * CommentDTO commentDTO = new CommentDTO(); commentDTO.setId(comment.getId());
		 * commentDTO.setName(comment.getName());
		 * commentDTO.setEmail(comment.getEmail());
		 * commentDTO.setBody(comment.getBody()); return commentDTO;
		 */
		// changing above code with mapper
		CommentDTO commentDTO = mapper.map(comment, CommentDTO.class);
		return commentDTO;

	}

	private Comment mapToEntity(CommentDTO commentDTO) {
		/*
		 * Comment comment = new Comment(); comment.setId(commentDTO.getId());
		 * comment.setName(commentDTO.getName());
		 * comment.setEmail(commentDTO.getEmail());
		 * comment.setBody(commentDTO.getBody()); return comment;
		 */
		// changing above code using mapper
		Comment comment = mapper.map(commentDTO, Comment.class);
		return comment;
	}

	// for get all comments by post id
	@Override
	public List<CommentDTO> getCommentsByPostId(long postId) {
		// retrieve comments by post id
		List<Comment> comments = commentRepository.findByPostId(postId);
		// convert list of comment entities into comment dtos
		return comments.stream().map(comment -> mapToDTO(comment)).collect(Collectors.toList());
	}

	@Override
	public CommentDTO getCommentById(Long postId, Long commentId) {
		// retrieve post entity by id
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));
		// retrieve comment by id
		Comment comment = commentRepository.findById(commentId)
				.orElseThrow(() -> new ResourceNotFoundException("comment", "id", commentId));
		if (!comment.getPost().getId().equals(post.getId())) {
			throw new BlogApiException(HttpStatus.BAD_REQUEST, "comment does not belong to the post");
		}
		return mapToDTO(comment);
	}

	@Override
	public CommentDTO updateComment(Long postId, Long commentId, CommentDTO commentRequest) {
		// retrieve post entity by id
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));
		// retrieve comment by id
		Comment comment = commentRepository.findById(commentId)
				.orElseThrow(() -> new ResourceNotFoundException("comment", "id", commentId));
		if (!comment.getPost().getId().equals(post.getId())) {
			throw new BlogApiException(HttpStatus.BAD_REQUEST, "comment does not belong to the post");
		}
		comment.setName(commentRequest.getName());
		comment.setEmail(commentRequest.getEmail());
		comment.setBody(commentRequest.getBody());
		Comment updatedComment = commentRepository.save(comment);
		return mapToDTO(updatedComment);
	}

	@Override
	public void deleteComment(Long postId, Long commentId) {
		// retrieve post entity by id
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));
		// retrieve comment by id
		Comment comment = commentRepository.findById(commentId)
				.orElseThrow(() -> new ResourceNotFoundException("comment", "id", commentId));
		if (!comment.getPost().getId().equals(post.getId())) {
			throw new BlogApiException(HttpStatus.BAD_REQUEST, "comment does not belong to the post");
		}
		commentRepository.delete(comment);
	}

}
