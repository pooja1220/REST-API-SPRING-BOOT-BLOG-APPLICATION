package com.pooja.blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBlogAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
